import zipfile,os
exclude_dirs = {'.git','venv','uploads','__pycache__'}
exclude_files = {'.env'}
root='.'
zipfn=os.path.join('..','backend-deploy.zip')
with zipfile.ZipFile(zipfn,'w',zipfile.ZIP_DEFLATED) as z:
    for dirpath, dirnames, filenames in os.walk(root):
        if any(part in exclude_dirs for part in dirpath.split(os.sep)):
            continue
        for fn in filenames:
            if fn in exclude_files:
                continue
            fp = os.path.join(dirpath, fn)
            arc = os.path.relpath(fp, root)
            z.write(fp, arc)
print('WROTE', zipfn)
